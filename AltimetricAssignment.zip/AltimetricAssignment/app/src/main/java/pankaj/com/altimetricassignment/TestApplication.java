package pankaj.com.altimetricassignment;

import android.app.Application;
import android.content.Context;

/**
 * Created by Pankaj Kumar on 7/22/2017.
 * pankaj.arrah@gmail.com
 */
public class TestApplication extends Application {

    /**
     * This is a global context which can be used into non component classes
     * which will be avoiding passing context between callbacks.
     *
     * This will also help to write more testable code.
     */
    public static Context appContext;

    @Override
    public void onCreate() {
        super.onCreate();
        appContext = this;
    }
}
