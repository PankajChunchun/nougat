package pankaj.com.altimetricassignment;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.HashMap;

import pankaj.com.altimetricassignment.model.TestModel;
import pankaj.com.altimetricassignment.presenter.TestPresenter;
import pankaj.com.altimetricassignment.presenter.TestPresenterImpl;
import pankaj.com.altimetricassignment.view.TestUIInterface;

public class MainActivity extends AppCompatActivity implements TestUIInterface {
    private TextView mTextView;
    private ProgressBar mProgressBar;
    private Button mButton;
    private TestPresenter mTestPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialise view and listeners.
        initView();
        initListener();
    }

    private void initView() {
        mTextView = (TextView) findViewById(R.id.output_text);
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mButton = (Button) findViewById(R.id.button);
        // Create presenter and associate with view
        mTestPresenter = new TestPresenterImpl(this);
    }

    private void initListener() {
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mProgressBar.setVisibility(View.VISIBLE);
                mTextView.setVisibility(View.GONE);
                mTestPresenter.getJsonFromNetwrok();
            }
        });
    }

    @Override
    public void onRetrieveInfoFailed() {
        if (! isFinishing() && mTextView != null) {

            mProgressBar.post(new Runnable() {
                @Override
                public void run() {
                    mProgressBar.setVisibility(View.GONE);
                    mTextView.setVisibility(View.VISIBLE);
                    mTextView.setText("Error while reading info");
                }
            });
        }
    }

    @Override
    public void onRetrieveInfoSucess(final TestModel result) {
        if (! isFinishing() && mTextView != null) {
            mProgressBar.post(new Runnable() {
                @Override
                public void run() {
                    mProgressBar.setVisibility(View.GONE);
                    mTextView.setVisibility(View.VISIBLE);

                    // Prepare result to show on UI.
                    // TODO Code should be modified to show information on UI as per requirement.
                    // TODO A listview/ Recylerview can be used in such cases if you want to show info as list.

                    StringBuilder sb = new StringBuilder();
                    HashMap<String, Object> info = result.getResponse();
                    for (String key : info.keySet()) {
                        sb.append(key).append(" : ").append(String.valueOf(info.get(key))).append("\n");
                    }

                    mTextView.setText(sb.toString());
                }
            });

        }
    }
}
