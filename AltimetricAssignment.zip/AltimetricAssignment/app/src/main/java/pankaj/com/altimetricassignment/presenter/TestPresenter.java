package pankaj.com.altimetricassignment.presenter;

import pankaj.com.altimetricassignment.model.TestModel;

/**
 * Created by Pankaj Kumar on 7/22/2017.
 * pankaj.arrah@gmail.com
 */
public interface TestPresenter {
    void getJsonFromNetwrok();
    void onJsonFromNetworkSuccess(TestModel testModel);
    void onJsonEromNetworkFailed();
}
