package pankaj.com.altimetricassignment.model;

import java.util.HashMap;
import java.util.Objects;

/**
 * Created by Pankaj Kumar on 7/22/2017.
 * pankaj.arrah@gmail.com
 */
public class TestModel {
    private HashMap<String, Object> response;

    public HashMap<String, Object> getResponse() {
        return response;
    }
}
