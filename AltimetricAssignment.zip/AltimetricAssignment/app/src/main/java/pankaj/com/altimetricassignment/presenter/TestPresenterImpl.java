package pankaj.com.altimetricassignment.presenter;

import pankaj.com.altimetricassignment.model.TestModel;
import pankaj.com.altimetricassignment.model.NetworkUtility;
import pankaj.com.altimetricassignment.view.TestUIInterface;

/**
 * A Presenter which will get requests from View and can pass it to Model
 * to do network or other data layer tasks.
 *
 * Created by Pankaj Kumar on 7/22/2017.
 * pankaj.arrah@gmail.com
 */
public class TestPresenterImpl implements TestPresenter {
    private TestUIInterface mTestUIInterface;

    public TestPresenterImpl(TestUIInterface uiInterface) {
        mTestUIInterface = uiInterface;
    }

    @Override
    public void getJsonFromNetwrok() {
        // TODO Modify code to do actual network call.
        NetworkUtility.getInformation(this);
    }

    @Override
    public void onJsonEromNetworkFailed() {
        mTestUIInterface.onRetrieveInfoFailed();
    }

    @Override
    public void onJsonFromNetworkSuccess(TestModel testModel) {
        mTestUIInterface.onRetrieveInfoSucess(testModel);
    }
}
