package pankaj.com.altimetricassignment.view;

import pankaj.com.altimetricassignment.model.TestModel;

/**
 * Created by Pankaj Kumar on 7/22/2017.
 * pankaj.arrah@gmail.com
 */
public interface TestUIInterface {
    void onRetrieveInfoSucess(TestModel result);

    void onRetrieveInfoFailed();
}
