package pankaj.com.altimetricassignment.model;

import android.support.annotation.WorkerThread;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import java.io.IOException;
import java.io.InputStream;

import pankaj.com.altimetricassignment.TestApplication;
import pankaj.com.altimetricassignment.presenter.TestPresenter;

/**
 * Utility to handle network call.
 * <p/>
 * This can pass callbacks to presenter if required.
 * <p/>
 * Created by Pankaj Kumar on 7/22/2017.
 * pankaj.arrah@gmail.com
 */
public final class NetworkUtility {

    private NetworkUtility() {
        throw new UnsupportedOperationException(NetworkUtility.class.getSimpleName() + " Can not be instanciated..");
    }

    /**
     * Reading information from local. This method can be modified to use
     * network libraries like retrofit or okhttp.
     *
     * @param presenter - {@link TestPresenter} A callback will be passed to presenter
     *                  after retrieving data from network. {@link TestPresenter#onJsonFromNetworkSuccess(TestModel)}
     *                  if network call got success, otherwise {@link TestPresenter#onJsonEromNetworkFailed()}.
     */
    public static void getInformation(final TestPresenter presenter) {

        Thread worker = new Thread(new Runnable() {
            @Override
            public void run() {
                String string = readLocalJson();
                if (string != null) {
                    Gson gson = new Gson();
                    TestModel result = null;
                    try {
                        result = gson.fromJson(string, TestModel.class);
                    } catch (JsonSyntaxException e) {

                    }

                    if (result == null) {
                        presenter.onJsonEromNetworkFailed();
                    } else {
                        presenter.onJsonFromNetworkSuccess(result);
                    }
                } else {
                    presenter.onJsonEromNetworkFailed();
                }
            }
        });
        worker.start();
    }


    /**
     * Reading JSON from asset. This method must not call from main thread.
     * It should be called on worker thread.
     *
     * @return
     */
    @WorkerThread
    private static String readLocalJson() {
        String json = null;
        try {
            InputStream is = TestApplication.appContext.getAssets().open("document.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }
}
