package com.example.hp.loadurlassigment.subscribers;

import com.example.hp.loadurlassigment.beans.RequestIds;
import com.example.hp.loadurlassigment.networks.NetworkUtility;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;

/**
 * Created by hp on 22-07-2017.
 */

public class SubscriberHelper {

    private Subscription mSubscription;
    private FlowableEmitter mFlowableEmitter;
    private SubscriberCallback mSubscriberCallback;

    public SubscriberHelper(SubscriberCallback downloadableObjCallback) {
        mSubscriberCallback = downloadableObjCallback;
        FlowableOnSubscribe flowableOnSubscribe = new FlowableOnSubscribe() {
            @Override
            public void subscribe(FlowableEmitter e) throws Exception {
                mFlowableEmitter = e;
            }
        };

        final Flowable flowable = Flowable.create(flowableOnSubscribe, BackpressureStrategy.BUFFER);
        final Subscriber subscriber = getSubscriber();
        flowable.subscribeWith(subscriber);
    }

    public void requestNextDownloads(int number) {
        mSubscription.request(number);
    }

    public void emitNextItem(int toFetchInfo) {
        mFlowableEmitter.onNext(toFetchInfo);
    }

    private Subscriber getSubscriber() {
        return new Subscriber() {
            @Override
            public void onSubscribe(Subscription s) {
                mSubscription = s;
                mSubscription.request(NetworkUtility.MAX_CON_REQUEST);
            }

            @Override
            public void onNext(Object o) {
                if (!(o instanceof RequestIds)) {
                    return;
                }
                mSubscriberCallback.onDownloadStarted((RequestIds) o);
            }

            @Override
            public void onError(Throwable t) {

            }

            @Override
            public void onComplete() {

            }
        };
    }

    public void performCleanUp() {
        if (mSubscription != null) {
            mSubscription.cancel();
        }
    }

}
