package com.example.hp.loadurlassigment.beans;

/**
 * Created by hp on 22-07-2017.
 */

public class InfoWithId {
    // TODO Other fileds can be added here.
    // For List only title is required so, only title has been taken.
    private String title;

    public String getTitle() {
        return this.title;
    }
}
