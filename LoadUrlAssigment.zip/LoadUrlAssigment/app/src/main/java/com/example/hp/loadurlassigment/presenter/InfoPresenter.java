package com.example.hp.loadurlassigment.presenter;

import com.example.hp.loadurlassigment.beans.InfoWithId;
import com.example.hp.loadurlassigment.beans.RequestIds;

/**
 * Created by hp on 22-07-2017.
 */

public interface InfoPresenter {
    void getAllIds();
    void getInfoWithIds(int id);
    void onAllIdsSuccess(RequestIds ids);
    void onAllIdsError();
    void onInfoWithIdSuccess(InfoWithId info);
    void onInfoWithIdError();
}
