package com.example.hp.loadurlassigment.beans;

import java.util.ArrayList;

/**
 * Modal to handle Array of integers.
 * Created by hp on 22-07-2017.
 */

public class RequestIds extends ArrayList<Integer> {

}
