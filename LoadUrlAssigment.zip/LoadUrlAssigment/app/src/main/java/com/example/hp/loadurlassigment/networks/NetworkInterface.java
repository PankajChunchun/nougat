package com.example.hp.loadurlassigment.networks;

import com.example.hp.loadurlassigment.beans.InfoWithId;
import com.example.hp.loadurlassigment.beans.RequestIds;

import retrofit2.http.GET;
import retrofit2.Call;
import retrofit2.http.Path;

/**
 * Created by hp on 22-07-2017.
 */

public interface NetworkInterface {
    @GET("v0/topstories.json")
    Call<RequestIds> getAllIds();

    @GET("v0/item/{id}")
    Call<InfoWithId> getInfoById(@Path("id") int id);
}
