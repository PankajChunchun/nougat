package com.example.hp.loadurlassigment;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.ProgressBar;

import com.example.hp.loadurlassigment.adapter.InfoAdapter;
import com.example.hp.loadurlassigment.beans.InfoWithId;
import com.example.hp.loadurlassigment.beans.RequestIds;
import com.example.hp.loadurlassigment.networks.NetworkUtility;
import com.example.hp.loadurlassigment.subscribers.SubscriberCallback;
import com.example.hp.loadurlassigment.subscribers.SubscriberHelper;
import com.example.hp.loadurlassigment.view.MainActivityUICallbacks;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements SubscriberCallback, MainActivityUICallbacks {

    // Subscriber to handle multiple calls.
    // In curent logic has been implemented as it will emit maximum 5
    // requests to handle. To download information associated with each id
    // all id will be given to Subscriber, and that will control emitting data
    // with maximum 5 at a time.
    private SubscriberHelper mSubscriberHelper;
    // Handle counetr to remember download counts
    private int mDownloadCounter = 0;
    private RecyclerView mRecyclerView;
    private InfoAdapter mInfoAdapter;
    // Show progress till Subscriber emiting data.
    // And when it will complete with last request call, hide progressbar.
    private ProgressBar mProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRecyclerView = (RecyclerView) findViewById(R.id.info_recycler_view);
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mInfoAdapter = new InfoAdapter(MainActivity.this, new ArrayList<InfoWithId>());
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mSubscriberHelper = new SubscriberHelper(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mSubscriberHelper.performCleanUp();
    }

    @Override
    public void onDownloadComplete() {
        // Decrease counter
        mDownloadCounter--;
        // Notify Subscriber to emmit maximum observerables
        mSubscriberHelper.requestNextDownloads(NetworkUtility.MAX_CON_REQUEST - mDownloadCounter);
    }

    @Override
    public void onDownloadRequested(int id) {
        mSubscriberHelper.emitNextItem(id);
    }

    @Override
    public void onDownloadStarted(RequestIds downloadableItem) {
        // Increase conter to be used to notify Subscriber that how many
        // items to be emmited
        mDownloadCounter++;
    }

    @Override
    public void onInfoWithIdError() {

        // TODO Handle error
        // In this case next call not be hapen
    }

    @Override
    public void onAllIdsError() {

        // TODO Handle error
    }

    @Override
    public void onNewInfoDownloaded(InfoWithId infoWithId) {
        // Upadte Adapter and notify obsever to emmit new request to be handled
        mInfoAdapter.addAndNotifyNewInfo(infoWithId);
        onDownloadComplete();
    }

    @Override
    public void onAllIdsDownloaded(RequestIds requestIds) {
        // Here we got all ids in a list
        // Push all ids to Subscriber to handle all requests.
        // TODO In Current maximum 5 request can be handled at sametime.
        // TODO Change limit NetworkUtility.MAX_CON_REQUEST

        for (Integer id : requestIds) {
            onDownloadRequested(id);
        }
    }
}
