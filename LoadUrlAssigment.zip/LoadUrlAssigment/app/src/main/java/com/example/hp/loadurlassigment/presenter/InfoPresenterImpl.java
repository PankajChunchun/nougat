package com.example.hp.loadurlassigment.presenter;

import com.example.hp.loadurlassigment.beans.InfoWithId;
import com.example.hp.loadurlassigment.beans.RequestIds;
import com.example.hp.loadurlassigment.networks.NetworkUtility;
import com.example.hp.loadurlassigment.view.MainActivityUICallbacks;

/**
 * Created by hp on 22-07-2017.
 */

public class InfoPresenterImpl implements InfoPresenter {
    private MainActivityUICallbacks mUICallbacks;

    public InfoPresenterImpl(MainActivityUICallbacks callback) {
        mUICallbacks = callback;
    }

    @Override
    public void onAllIdsError() {
        mUICallbacks.onAllIdsError();
    }

    @Override
    public void onAllIdsSuccess(RequestIds ids) {
        mUICallbacks.onAllIdsDownloaded(ids);
    }

    @Override
    public void onInfoWithIdError() {
        mUICallbacks.onInfoWithIdError();
    }

    @Override
    public void onInfoWithIdSuccess(InfoWithId info) {
        mUICallbacks.onNewInfoDownloaded(info);
    }

    @Override
    public void getAllIds() {
        NetworkUtility.getAllIds(this);
    }

    @Override
    public void getInfoWithIds(int id) {
        NetworkUtility.getInfoWithId(this, id);
    }
}
