package com.example.hp.loadurlassigment.subscribers;

import com.example.hp.loadurlassigment.beans.RequestIds;

/**
 * Created by hp on 22-07-2017.
 */

public interface SubscriberCallback {
    void onDownloadRequested(int downloadableItem);

    void onDownloadStarted(RequestIds downloadableItem);

    void onDownloadComplete();
}
