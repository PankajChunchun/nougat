package com.example.hp.loadurlassigment.networks;

import android.util.Log;

import com.example.hp.loadurlassigment.beans.InfoWithId;
import com.example.hp.loadurlassigment.beans.RequestIds;
import com.example.hp.loadurlassigment.presenter.InfoPresenter;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * An utility class to handle Retrofit calls.
 * Created by hp on 22-07-2017.
 */

public final class NetworkUtility {
    public static final int MAX_CON_REQUEST = 5;

    private NetworkUtility() {
        throw new UnsupportedOperationException("Can not be instansiated");
    }

    /**
     * Get All ids from server.
     *
     * @param presenter - {@link InfoPresenter} to get callbacks for result.
     */
    public static void getAllIds(final InfoPresenter presenter) {
        NetworkInterface apiService =
                NetworkClient.getClient().create(NetworkInterface.class);

        Call<RequestIds> call = apiService.getAllIds();
        call.enqueue(new Callback<RequestIds>() {
            @Override
            public void onResponse(Call<RequestIds> call, Response<RequestIds> response) {
                RequestIds ids = response.body();
                Log.d("PANKAJ", "Number of ids received: " + ids.size());
                presenter.onAllIdsSuccess(ids);
            }

            @Override
            public void onFailure(Call<RequestIds> call, Throwable t) {
                // Log error here since request failed
                Log.e("PANKAJ", t.toString());
                presenter.onAllIdsError();
            }
        });
    }

    /**
     * Get {@link InfoWithId} for given Id from server.
     *
     * @param presenter - {@link InfoPresenter} to handle callbacks on result
     * @param id-       Id to which information needed to retrieve.
     */
    public static void getInfoWithId(final InfoPresenter presenter, int id) {
        NetworkInterface apiService =
                NetworkClient.getClient().create(NetworkInterface.class);

        Call<InfoWithId> call = apiService.getInfoById(id);
        call.enqueue(new Callback<InfoWithId>() {
            @Override
            public void onResponse(Call<InfoWithId> call, Response<InfoWithId> response) {
                InfoWithId info = response.body();
                Log.d("PANKAJ", "Info received: " + info.getTitle());
                presenter.onInfoWithIdSuccess(info);
            }

            @Override
            public void onFailure(Call<InfoWithId> call, Throwable t) {
                // Log error here since request failed
                Log.e("PANKAJ", t.toString());
                presenter.onInfoWithIdError();
            }
        });
    }
}
