package com.example.hp.loadurlassigment.view;

import com.example.hp.loadurlassigment.beans.InfoWithId;
import com.example.hp.loadurlassigment.beans.RequestIds;

/**
 * View Callbacks which can be used to update UI
 * or initiate next action from View.
 * <p>
 * Created by hp on 22-07-2017.
 */

public interface MainActivityUICallbacks {
    void onNewInfoDownloaded(InfoWithId infoWithId);

    void onAllIdsDownloaded(RequestIds requestIds);

    void onAllIdsError();

    void onInfoWithIdError();
}
