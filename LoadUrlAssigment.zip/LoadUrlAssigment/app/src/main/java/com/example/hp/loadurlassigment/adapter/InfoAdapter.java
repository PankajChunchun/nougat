package com.example.hp.loadurlassigment.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.hp.loadurlassigment.R;
import com.example.hp.loadurlassigment.beans.InfoWithId;

import java.util.List;

/**
 * Created by hp on 22-07-2017.
 */

public class InfoAdapter extends RecyclerView.Adapter<InfoAdapter.InfoViewHolder> {

    private List<InfoWithId> infos;
    private int rowLayout;
    private Context context;

    public static class InfoViewHolder extends RecyclerView.ViewHolder {
        TextView mTitleTv;


        public InfoViewHolder(View v) {
            super(v);
            mTitleTv = (TextView) v.findViewById(R.id.title_tv);
        }
    }

    public InfoAdapter(Context context, List<InfoWithId> infoWithIdList) {
        this.infos = infoWithIdList;
        this.context = context;
    }

    @Override
    public InfoAdapter.InfoViewHolder onCreateViewHolder(ViewGroup parent,
                                                            int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.info_row_view, parent, false);
        return new InfoViewHolder(view);
    }


    @Override
    public void onBindViewHolder(InfoViewHolder holder, final int position) {
        holder.mTitleTv.setText(infos.get(position).getTitle());
    }

    @Override
    public int getItemCount() {
        return infos.size();
    }

    public void addAndNotifyNewInfo(InfoWithId infoWithId) {
        infos.add(infoWithId);
        notifyDataSetChanged();
    }
}

