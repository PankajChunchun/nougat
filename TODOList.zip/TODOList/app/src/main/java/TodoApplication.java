import android.app.Application;

import com.google.firebase.database.FirebaseDatabase;

/**
 * Created by 473708 on 8/9/2017.
 */

public class TodoApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        FirebaseDatabase.getInstance().setPersistenceEnabled(true);
    }
}
