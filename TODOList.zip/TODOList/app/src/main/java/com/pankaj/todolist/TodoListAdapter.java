package com.pankaj.todolist;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckedTextView;
import android.widget.TextView;

import com.pankaj.todolist.bean.TodoItem;

import java.util.List;

/**
 * Created by 473708 on 8/9/2017.
 */

public class TodoListAdapter extends RecyclerView.Adapter<TodoListAdapter.ViewHolder> {

    private List<TodoItem> notes;

    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        CheckedTextView titleTextView;
        TextView descriptionTextView;
        private TodoItem note;

        public ViewHolder(View itemView) {
            super(itemView);
            titleTextView = (CheckedTextView) itemView.findViewById(R.id.note_title);
            descriptionTextView = (TextView) itemView.findViewById(R.id.note_description);
            itemView.setOnClickListener(this);
        }

        public void bind(TodoItem note) {
            this.note = note;
            titleTextView.setText(note.getTitle());
            descriptionTextView.setText(note.getDescription());
        }

        @Override
        public void onClick(View view) {
            Context context = view.getContext();
            // TODO Start todoactivity in edit mode
            // context.startActivity(TodoActivity.newInstance(context, note));
        }
    }

    public TodoListAdapter(List<TodoItem> notes) {
        this.notes = notes;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.todo_item_row_view, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.bind(notes.get(position));
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    public void updateList(List<TodoItem> notes) {
        // Allow recyclerview animations to complete normally if we already know about data changes
        if (notes.size() != this.notes.size() || !this.notes.containsAll(notes)) {
            this.notes = notes;
            notifyDataSetChanged();
        }
    }

    public void removeItem(int position) {
        notes.remove(position);
        notifyItemRemoved(position);
    }

    public TodoItem getItem(int position) {
        return notes.get(position);
    }
}