package com.pankaj.todolist.db;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.pankaj.todolist.bean.TodoItem;

/**
 * Created by 473708 on 8/9/2017.
 */

public class DbManager {
    private static final String TODO_DATA = "todo";


    public static void addNewTodo(String title, String desc) {
        DatabaseReference db = FirebaseDatabase.getInstance().getReference();
        TodoItem todoItem = new TodoItem();
        todoItem.setUid(db.child(TODO_DATA).push().getKey());
        todoItem.setTitle(title.trim());
        todoItem.setDescription(desc.trim());
        todoItem.setCompleted(false);
        db.child(TODO_DATA).child(todoItem.getUid()).setValue(todoItem);
    }

    private void createTodo(DatabaseReference databaseReference, TodoItem todoItem) {
        databaseReference.child(TODO_DATA).child(todoItem.getUid()).setValue(todoItem);
    }
}
