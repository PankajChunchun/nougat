package com.pankaj.todolist.bean;

/**
 * Created by 473708 on 8/9/2017.
 */

public class User {

    private String name;
    private String email;
}
