package com.pankaj.todolist.listeners;

/**
 * Created by 473708 on 8/9/2017.
 */

public interface DeletionListener {
    void itemRemoved(int position);
}